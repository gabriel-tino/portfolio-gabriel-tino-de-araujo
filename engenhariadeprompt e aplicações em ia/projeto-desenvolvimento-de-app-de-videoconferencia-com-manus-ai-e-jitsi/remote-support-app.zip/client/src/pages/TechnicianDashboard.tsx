import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import { Plus, LogOut, Loader2, AlertCircle } from "lucide-react";
import React, { useState } from "react";
import { toast } from "sonner";

export default function TechnicianDashboard() {
  const { user, logout } = useAuth();
  const [, navigate] = useLocation();
  const [showCreateModal, setShowCreateModal] = useState(false);

  // Redirect non-admin users
  if (user?.role !== "admin") {
    navigate("/");
    return null;
  }

  const { data: sessions, isLoading, refetch } = trpc.sessions.list.useQuery();
  const { data: pendingHelpRequests } = trpc.helpRequests.getPending.useQuery();
  const createSession = trpc.sessions.create.useMutation({
    onSuccess: (data) => {
      toast.success(`Sessão criada! Código: ${data.accessCode}`);
      setShowCreateModal(false);
      refetch();
    },
    onError: (error) => {
      toast.error("Erro ao criar sessão: " + error.message);
    },
  });

  const handleLogout = async () => {
    await logout();
    navigate("/");
  };

  const activeSessions = sessions?.filter((s) => s.status === "active") || [];
  const pendingSessions = sessions?.filter((s) => s.status === "pending") || [];
  const completedSessions = sessions?.filter((s) => s.status === "completed") || [];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Dashboard de Suporte</h1>
            <p className="text-sm text-muted-foreground mt-1">Bem-vindo, {user?.name}</p>
          </div>
          <div className="flex items-center gap-3">
            <Button
              onClick={() => setShowCreateModal(true)}
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nova Sessão
            </Button>
            <Button variant="ghost" size="sm" onClick={handleLogout}>
              <LogOut className="w-4 h-4 mr-2" />
              Sair
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {/* Stats */}
        <div className="grid md:grid-cols-3 gap-6 mb-8">
          <StatCard
            title="Sessões Ativas"
            value={activeSessions.length}
            color="text-accent"
          />
          <StatCard
            title="Pendentes"
            value={pendingSessions.length}
            color="text-yellow-500"
          />
          <StatCard
            title="Concluídas"
            value={completedSessions.length}
            color="text-green-500"
          />
        </div>

        {/* Sessions List */}
        <div className="space-y-6">
          {/* Active Sessions */}
          <SessionsSection
            title="Sessões Ativas"
            sessions={activeSessions}
            status="active"
            isLoading={isLoading}
          />

          {/* Pending Sessions */}
          <SessionsSection
            title="Sessões Pendentes"
            sessions={pendingSessions}
            status="pending"
            isLoading={isLoading}
          />

          {/* Completed Sessions */}
          <SessionsSection
            title="Sessões Concluídas"
            sessions={completedSessions}
            status="completed"
            isLoading={isLoading}
          />

          {/* Help Requests */}
          {pendingHelpRequests && pendingHelpRequests.length > 0 && (
            <div className="bg-card border border-accent rounded-xl overflow-hidden">
              <div className="px-6 py-4 border-b border-border bg-accent/10">
                <h2 className="text-lg font-semibold text-foreground">
                  🆘 Solicitações de Ajuda ({pendingHelpRequests.length})
                </h2>
              </div>
              <div className="divide-y divide-border">
                {pendingHelpRequests.map((request: any) => (
                  <div key={request.id} className="px-6 py-4 hover:bg-muted/50 transition-colors">
                    <div className="flex items-center justify-between">
                      <div className="flex-1">
                        <p className="font-semibold text-foreground">
                          {request.peripheralType.charAt(0).toUpperCase() + request.peripheralType.slice(1)}
                        </p>
                        <p className="text-sm text-muted-foreground mt-1">{request.description}</p>
                        <p className="text-xs text-muted-foreground mt-2">
                          {new Date(request.createdAt).toLocaleString("pt-BR")}
                        </p>
                      </div>
                      <div className="ml-4">
                        <span className="px-3 py-1 rounded-full text-sm font-medium bg-yellow-100 text-yellow-800">
                          Pendente
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </main>

      {/* Create Session Modal */}
      {showCreateModal && (
        <CreateSessionModal
          onClose={() => setShowCreateModal(false)}
          onSubmit={(data) => createSession.mutate(data)}
          isLoading={createSession.isPending}
        />
      )}
    </div>
  );
}

function StatCard({
  title,
  value,
  color,
}: {
  title: string;
  value: number;
  color: string;
}) {
  return (
    <div className="bg-card border border-border rounded-xl p-6">
      <p className="text-sm text-muted-foreground mb-2">{title}</p>
      <p className={`text-4xl font-bold ${color}`}>{value}</p>
    </div>
  );
}

function SessionsSection({
  title,
  sessions,
  status,
  isLoading,
}: {
  title: string;
  sessions: any[];
  status: string;
  isLoading: boolean;
}) {
  if (isLoading) {
    return (
      <div className="bg-card border border-border rounded-xl p-8 text-center">
        <Loader2 className="w-6 h-6 animate-spin mx-auto text-accent mb-2" />
        <p className="text-muted-foreground">Carregando sessões...</p>
      </div>
    );
  }

  if (sessions.length === 0) {
    return null;
  }

  return (
    <div className="bg-card border border-border rounded-xl overflow-hidden">
      <div className="px-6 py-4 border-b border-border">
        <h2 className="text-lg font-semibold text-foreground">{title}</h2>
      </div>
      <div className="divide-y divide-border">
        {sessions.map((session) => (
          <SessionRow key={session.id} session={session} />
        ))}
      </div>
    </div>
  );
}

function SessionRow({ session }: { session: any }) {
  const [, navigate] = useLocation();

  const getStatusBadge = (status: string) => {
    const badges: Record<string, { bg: string; text: string; label: string }> =
      {
        pending: { bg: "bg-yellow-100", text: "text-yellow-800", label: "Pendente" },
        active: { bg: "bg-green-100", text: "text-green-800", label: "Ativa" },
        completed: { bg: "bg-blue-100", text: "text-blue-800", label: "Concluída" },
        cancelled: { bg: "bg-red-100", text: "text-red-800", label: "Cancelada" },
      };
    const badge = badges[status] || badges.pending;
    return (
      <span className={`px-3 py-1 rounded-full text-sm font-medium ${badge.bg} ${badge.text}`}>
        {badge.label}
      </span>
    );
  };

  return (
    <div className="px-6 py-4 flex items-center justify-between hover:bg-muted/50 transition-colors">
      <div className="flex-1">
        <div className="flex items-center gap-4">
          <div>
            <p className="font-semibold text-foreground">
              {session.clientName || "Cliente Não Identificado"}
            </p>
            <p className="text-sm text-muted-foreground">
              Código: <span className="font-mono text-accent">{session.accessCode}</span>
            </p>
            {session.clientEmail && (
              <p className="text-sm text-muted-foreground">{session.clientEmail}</p>
            )}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-4">
        {getStatusBadge(session.status)}
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate(`/session/${session.id}`)}
        >
          Abrir
        </Button>
      </div>
    </div>
  );
}

function CreateSessionModal({
  onClose,
  onSubmit,
  isLoading,
}: {
  onClose: () => void;
  onSubmit: (data: any) => void;
  isLoading: boolean;
}) {
  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    onSubmit({
      clientName: clientName || undefined,
      clientEmail: clientEmail || undefined,
    });
  };

  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50">
      <div className="bg-card border border-border rounded-xl p-8 max-w-md w-full mx-4">
        <h2 className="text-2xl font-bold text-foreground mb-6">Nova Sessão de Suporte</h2>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Nome do Cliente (opcional)
            </label>
            <input
              type="text"
              placeholder="Ex: João Silva"
              value={clientName}
              onChange={(e) => setClientName(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-foreground mb-2">
              Email do Cliente (opcional)
            </label>
            <input
              type="email"
              placeholder="Ex: joao@example.com"
              value={clientEmail}
              onChange={(e) => setClientEmail(e.target.value)}
              className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            />
          </div>

          <div className="flex gap-3 pt-4">
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="flex-1"
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button
              type="submit"
              className="flex-1 bg-accent hover:bg-accent/90 text-accent-foreground"
              disabled={isLoading}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Criando...
                </>
              ) : (
                "Criar Sessão"
              )}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
