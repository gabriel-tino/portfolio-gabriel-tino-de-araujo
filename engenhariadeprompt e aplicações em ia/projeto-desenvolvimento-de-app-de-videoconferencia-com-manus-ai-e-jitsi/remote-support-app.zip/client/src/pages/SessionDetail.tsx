import { useRoute, useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, AlertCircle, MessageSquare, Send, Image as ImageIcon, X, Phone, PhoneOff } from "lucide-react";
import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import AnnotationTool from "@/components/AnnotationTool";
import JitsiMeet from "@/components/JitsiMeet";

export default function SessionDetail() {
  const [, params] = useRoute("/session/:id");
  const [, navigate] = useLocation();
  const sessionId = Number(params?.id);

  const [message, setMessage] = useState("");
  const [showAnnotationTool, setShowAnnotationTool] = useState(false);
  const [selectedScreenshot, setSelectedScreenshot] = useState<string | undefined>(undefined);
  const [activeVideoCall, setActiveVideoCall] = useState<any>(null);

  // Fetch session data
  const { data: session, isLoading: sessionLoading } = trpc.sessions.list.useQuery();
  const currentSession = session?.find((s) => s.id === sessionId);

  // Fetch messages
  const { data: messages, refetch: refetchMessages } = trpc.chat.getMessages.useQuery(
    { sessionId },
    { enabled: !!sessionId, refetchInterval: 2000 }
  );

  // Fetch screenshots
  const { data: screenshots } = trpc.media.getScreenshots.useQuery(
    { sessionId },
    { enabled: !!sessionId }
  );

  // Fetch annotations
  const { data: annotations } = trpc.media.getAnnotations.useQuery(
    { sessionId },
    { enabled: !!sessionId }
  );

  // Mutations
  const sendMessage = trpc.chat.send.useMutation({
    onSuccess: () => {
      setMessage("");
      refetchMessages();
    },
    onError: (error) => {
      toast.error("Erro ao enviar mensagem: " + error.message);
    },
  });

  const updateSessionStatus = trpc.sessions.updateStatus.useMutation({
    onSuccess: () => {
      toast.success("Status da sessão atualizado");
    },
    onError: (error) => {
      toast.error("Erro ao atualizar status: " + error.message);
    },
  });

  const uploadScreenshot = trpc.media.uploadScreenshot.useMutation({
    onSuccess: () => {
      toast.success("Screenshot compartilhado com sucesso!");
      setShowAnnotationTool(false);
    },
    onError: (error) => {
      toast.error("Erro ao compartilhar screenshot: " + error.message);
    },
  });

  const createVideoCall = trpc.videoCalls.create.useMutation({
    onSuccess: () => {
      const roomName = `support-${sessionId}-${Date.now()}`;
      setActiveVideoCall({ roomName });
      toast.success("Videochamada iniciada!");
    },
    onError: (error) => {
      toast.error("Erro ao iniciar videochamada: " + error.message);
    },
  });

  const handleSaveAnnotations = (canvas: HTMLCanvasElement, actions: any[]) => {
    try {
      const dataUrl = canvas.toDataURL("image/png");
      const fileName = `annotation-${Date.now()}.png`;

      uploadScreenshot.mutate({
        sessionId,
        storageUrl: dataUrl,
        storageKey: fileName,
        originalFileName: fileName,
      });
    } catch (error) {
      toast.error("Erro ao salvar anotações");
    }
  };

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMessage.mutate({ sessionId, content: message });
  };

  const handleStartVideoCall = () => {
    const roomName = `support-${sessionId}-${Date.now()}`;
    createVideoCall.mutate({
      sessionId,
      jitsiRoomName: roomName,
      peripheralType: "general",
      description: "Videochamada de suporte",
    });
  };

  const handleEndVideoCall = () => {
    setActiveVideoCall(null);
    toast.success("Videochamada encerrada");
  };

  if (sessionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <p className="text-muted-foreground">Carregando sessão...</p>
        </div>
      </div>
    );
  }

  if (!currentSession) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="max-w-md w-full mx-4 bg-card border border-border rounded-xl p-8 text-center">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Sessão Não Encontrada</h1>
          <Button onClick={() => navigate("/dashboard")} className="mt-6 bg-accent hover:bg-accent/90 text-accent-foreground">
            Voltar ao Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {/* Video Call Overlay */}
      {activeVideoCall && (
        <JitsiMeet
          roomName={activeVideoCall.roomName}
          userName={currentSession.clientName || "Técnico"}
          onClose={() => setActiveVideoCall(null)}
          onCallEnd={handleEndVideoCall}
        />
      )}

      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">
              Sessão: {currentSession.clientName || "Cliente"}
            </h1>
            <p className="text-sm text-muted-foreground mt-1">
              Código: <span className="font-mono text-accent">{currentSession.accessCode}</span>
            </p>
          </div>
          <div className="flex items-center gap-3">
            {currentSession.status === "active" && (
              <Button
                onClick={handleStartVideoCall}
                disabled={createVideoCall.isPending || !!activeVideoCall}
                className="bg-green-600 hover:bg-green-700 text-white flex items-center gap-2"
              >
                <Phone className="w-4 h-4" />
                Iniciar Videochamada
              </Button>
            )}
            {currentSession.status === "pending" && (
              <Button
                onClick={() => updateSessionStatus.mutate({ sessionId, status: "active" })}
                className="bg-green-600 hover:bg-green-700 text-white"
              >
                Iniciar Sessão
              </Button>
            )}
            {currentSession.status === "active" && (
              <Button
                onClick={() => updateSessionStatus.mutate({ sessionId, status: "completed" })}
                variant="outline"
              >
                Encerrar Sessão
              </Button>
            )}
            <Button variant="ghost" onClick={() => navigate("/dashboard")}>
              Voltar
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-8 grid md:grid-cols-3 gap-6">
        {/* Chat Area */}
        <div className="md:col-span-2 flex flex-col">
          <div className="bg-card border border-border rounded-xl mb-6 p-6 flex flex-col h-96">
            <h2 className="text-lg font-semibold text-foreground mb-4">Chat</h2>
            <div className="flex-1 overflow-y-auto space-y-4 mb-6 border-t border-border pt-4">
              {!messages || messages.length === 0 ? (
                <div className="text-center text-muted-foreground py-8">
                  <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Nenhuma mensagem ainda</p>
                </div>
              ) : (
                messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.senderRole === "technician" ? "justify-end" : "justify-start"}`}
                  >
                    <div
                      className={`max-w-xs px-4 py-2 rounded-lg ${
                        msg.senderRole === "technician"
                          ? "bg-accent text-accent-foreground"
                          : "bg-muted text-muted-foreground"
                      }`}
                    >
                      <p className="text-sm">{msg.content}</p>
                      <p className="text-xs opacity-70 mt-1">
                        {new Date(msg.createdAt).toLocaleTimeString("pt-BR", {
                          hour: "2-digit",
                          minute: "2-digit",
                        })}
                      </p>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="flex gap-2 border-t border-border pt-4">
              <input
                type="text"
                placeholder="Digite sua mensagem..."
                value={message}
                onChange={(e) => setMessage(e.target.value)}
                className="flex-1 px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              />
              <Button
                type="submit"
                disabled={!message.trim() || sendMessage.isPending}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                <Send className="w-4 h-4" />
              </Button>
            </form>
          </div>

          {/* Screenshots Area */}
          <div className="bg-card border border-border rounded-xl p-6">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-lg font-semibold text-foreground">Screenshots</h2>
              <Button
                size="sm"
                onClick={() => setShowAnnotationTool(true)}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                <ImageIcon className="w-4 h-4 mr-2" />
                Compartilhar Anotação
              </Button>
            </div>

            {!screenshots || screenshots.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <ImageIcon className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Nenhum screenshot compartilhado ainda</p>
              </div>
            ) : (
              <div className="grid grid-cols-2 gap-4">
                {screenshots.map((screenshot) => (
                  <div
                    key={screenshot.id}
                    className="border border-border rounded-lg overflow-hidden hover:border-accent/50 transition-colors cursor-pointer"
                    onClick={() => setSelectedScreenshot(screenshot.storageUrl)}
                  >
                    <img
                      src={screenshot.storageUrl}
                      alt={screenshot.originalFileName || "Screenshot"}
                      className="w-full h-32 object-cover"
                    />
                    <div className="p-2 bg-muted/50">
                      <p className="text-xs text-muted-foreground truncate">
                        {screenshot.originalFileName}
                      </p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Video Call Status */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="font-semibold text-foreground mb-4 flex items-center gap-2">
              <Phone className="w-4 h-4" />
              Videoconferência
            </h3>
            {activeVideoCall ? (
              <div className="space-y-3">
                <div className="p-3 bg-green-100 rounded-lg border border-green-300">
                  <p className="text-sm font-semibold text-green-800">Chamada Ativa</p>
                  <p className="text-xs text-green-700 mt-1">Sala: {activeVideoCall.roomName}</p>
                </div>
                <Button
                  onClick={handleEndVideoCall}
                  className="w-full bg-red-600 hover:bg-red-700 text-white flex items-center justify-center gap-2"
                >
                  <PhoneOff className="w-4 h-4" />
                  Encerrar Chamada
                </Button>
              </div>
            ) : (
              <div className="space-y-3">
                <p className="text-sm text-muted-foreground">
                  {currentSession.status === "active"
                    ? "Clique no botão acima para iniciar uma videochamada com o cliente."
                    : "Inicie a sessão para ativar videochamadas."}
                </p>
                {currentSession.status === "active" && (
                  <Button
                    onClick={handleStartVideoCall}
                    disabled={createVideoCall.isPending}
                    className="w-full bg-accent hover:bg-accent/90 text-accent-foreground flex items-center justify-center gap-2"
                  >
                    <Phone className="w-4 h-4" />
                    Iniciar Vídeo
                  </Button>
                )}
              </div>
            )}
          </div>

          {/* Session Info */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="font-semibold text-foreground mb-4">Informações da Sessão</h3>
            <div className="space-y-3 text-sm">
              <div>
                <p className="text-muted-foreground">Status</p>
                <p className="font-semibold text-foreground capitalize">{currentSession.status}</p>
              </div>
              {currentSession.clientEmail && (
                <div>
                  <p className="text-muted-foreground">Email do Cliente</p>
                  <p className="font-semibold text-foreground">{currentSession.clientEmail}</p>
                </div>
              )}
              {currentSession.startedAt && (
                <div>
                  <p className="text-muted-foreground">Iniciada em</p>
                  <p className="font-semibold text-foreground">
                    {new Date(currentSession.startedAt).toLocaleString("pt-BR")}
                  </p>
                </div>
              )}
            </div>
          </div>

          {/* Statistics */}
          <div className="bg-card border border-border rounded-xl p-6">
            <h3 className="font-semibold text-foreground mb-4">Estatísticas</h3>
            <div className="space-y-3 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Mensagens</span>
                <span className="font-semibold text-foreground">{messages?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Screenshots</span>
                <span className="font-semibold text-foreground">{screenshots?.length || 0}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Anotações</span>
                <span className="font-semibold text-foreground">{annotations?.length || 0}</span>
              </div>
            </div>
          </div>
        </div>
      </main>

      {/* Annotation Tool Modal */}
      {showAnnotationTool && (
        <AnnotationTool
          imageUrl="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='800' height='600'%3E%3Crect fill='%23f0f0f0' width='800' height='600'/%3E%3C/svg%3E"
          onClose={() => setShowAnnotationTool(false)}
          onSave={handleSaveAnnotations}
        />
      )}

      {/* Screenshot Viewer Modal */}
      {selectedScreenshot && (
        <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
          <div className="relative max-w-4xl w-full">
            <button
              onClick={() => setSelectedScreenshot(undefined)}
              className="absolute -top-10 right-0 text-white hover:text-gray-300"
            >
              <X className="w-6 h-6" />
            </button>
            <img
              src={selectedScreenshot}
              alt="Screenshot"
              className="w-full rounded-lg"
            />
          </div>
        </div>
      )}
    </div>
  );
}
