import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { useLocation } from "wouter";
import { getLoginUrl } from "@/const";
import { Headphones, Shield, MessageSquare, Zap } from "lucide-react";

export default function Home() {
  const { user, isAuthenticated } = useAuth();
  const [, navigate] = useLocation();

  // Redirect authenticated technicians to dashboard
  if (isAuthenticated && user?.role === "admin") {
    navigate("/dashboard");
    return null;
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-background to-accent/5">
      {/* Navigation */}
      <nav className="border-b border-border/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Headphones className="w-6 h-6 text-accent" />
            <span className="text-xl font-semibold text-foreground">RemoteSupport</span>
          </div>
          {!isAuthenticated && (
            <a href={getLoginUrl()}>
              <Button className="bg-accent hover:bg-accent/90 text-accent-foreground">
                Login Técnico
              </Button>
            </a>
          )}
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-6xl mx-auto px-4 py-20 md:py-32">
        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <h1 className="text-5xl md:text-6xl font-bold text-foreground leading-tight">
              Suporte Técnico Remoto
              <span className="block text-accent">Elegante e Eficiente</span>
            </h1>
            <p className="text-lg text-muted-foreground leading-relaxed max-w-lg">
              Plataforma sofisticada para gerenciar sessões de suporte remoto com ferramentas avançadas de anotação em tela, chat em tempo real e histórico completo.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <a href={getLoginUrl()}>
                <Button size="lg" className="bg-accent hover:bg-accent/90 text-accent-foreground w-full sm:w-auto">
                  <Shield className="w-4 h-4 mr-2" />
                  Acessar como Técnico
                </Button>
              </a>
              <Button size="lg" variant="outline" className="w-full sm:w-auto" onClick={() => navigate("/client/demo")}>
                Explorar como Cliente
              </Button>
            </div>
          </div>

          {/* Features Grid */}
          <div className="grid gap-4">
            <div className="bg-card border border-border rounded-xl p-6 hover:border-accent/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                  <Zap className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Anotações em Tela</h3>
                  <p className="text-sm text-muted-foreground">Desenhe, marque e guie clientes com precisão</p>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 hover:border-accent/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                  <MessageSquare className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Chat em Tempo Real</h3>
                  <p className="text-sm text-muted-foreground">Comunicação fluida e organizada durante sessões</p>
                </div>
              </div>
            </div>

            <div className="bg-card border border-border rounded-xl p-6 hover:border-accent/50 transition-colors">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg bg-accent/10 flex items-center justify-center flex-shrink-0">
                  <Shield className="w-6 h-6 text-accent" />
                </div>
                <div>
                  <h3 className="font-semibold text-foreground mb-1">Segurança Completa</h3>
                  <p className="text-sm text-muted-foreground">Autenticação e controle de acesso por papéis</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Client Access Section */}
      <section className="bg-card border-t border-border">
        <div className="max-w-6xl mx-auto px-4 py-16">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-foreground mb-4">Acesso do Cliente</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Se você recebeu um código de acesso de um técnico, insira-o abaixo para iniciar a sessão de suporte
            </p>
          </div>

          <div className="max-w-md mx-auto">
            <ClientAccessForm />
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-background/50 backdrop-blur-sm">
        <div className="max-w-6xl mx-auto px-4 py-8 text-center text-sm text-muted-foreground">
          <p>RemoteSupport &copy; 2026. Todos os direitos reservados.</p>
        </div>
      </footer>
    </div>
  );
}

function ClientAccessForm() {
  const [accessCode, setAccessCode] = React.useState("");
  const [, navigate] = useLocation();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (accessCode.trim()) {
      navigate(`/client/${accessCode.toUpperCase()}`);
    }
  };

  return (
    <form onSubmit={handleSubmit} className="space-y-4">
      <div>
        <label className="block text-sm font-medium text-foreground mb-2">
          Código de Acesso
        </label>
        <input
          type="text"
          placeholder="Ex: ABC123"
          value={accessCode}
          onChange={(e) => setAccessCode(e.target.value.toUpperCase())}
          className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
        />
      </div>
      <Button type="submit" className="w-full bg-accent hover:bg-accent/90 text-accent-foreground">
        Acessar Sessão
      </Button>
    </form>
  );
}

import React from "react";
