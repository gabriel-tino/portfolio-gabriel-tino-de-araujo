import { useLocation, useRoute } from "wouter";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Loader2, AlertCircle, MessageSquare, Send, Phone } from "lucide-react";
import React, { useState, useEffect } from "react";
import { toast } from "sonner";
import JitsiMeet from "@/components/JitsiMeet";
import HelpRequestDialog from "@/components/HelpRequestDialog";

export default function ClientSession() {
  const [, params] = useRoute("/client/:accessCode");
  const [, navigate] = useLocation();
  const accessCode = params?.accessCode as string;

  const [clientName, setClientName] = useState("");
  const [clientEmail, setClientEmail] = useState("");
  const [sessionJoined, setSessionJoined] = useState(false);
  const [sessionId, setSessionId] = useState<number | null>(null);

  const { data: session, isLoading: sessionLoading } = trpc.sessions.getByAccessCode.useQuery(
    { accessCode },
    { enabled: !!accessCode && !sessionJoined }
  );

  const joinSession = trpc.sessions.join.useMutation({
    onSuccess: (data) => {
      setSessionId(data.sessionId);
      setSessionJoined(true);
      toast.success("Conectado à sessão de suporte!");
    },
    onError: (error) => {
      toast.error("Erro ao conectar: " + error.message);
    },
  });

  const handleJoinSession = (e: React.FormEvent) => {
    e.preventDefault();
    if (!clientName.trim()) {
      toast.error("Por favor, insira seu nome");
      return;
    }
    joinSession.mutate({
      accessCode,
      clientName,
      clientEmail: clientEmail || undefined,
    });
  };

  if (sessionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <p className="text-muted-foreground">Verificando sessão...</p>
        </div>
      </div>
    );
  }

  if (!session && !sessionLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="max-w-md w-full mx-4 bg-card border border-border rounded-xl p-8 text-center">
          <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
          <h1 className="text-2xl font-bold text-foreground mb-2">Sessão Não Encontrada</h1>
          <p className="text-muted-foreground mb-6">
            O código de acesso "{accessCode}" não é válido ou expirou.
          </p>
          <Button onClick={() => navigate("/")} className="bg-accent hover:bg-accent/90 text-accent-foreground">
            Voltar para Home
          </Button>
        </div>
      </div>
    );
  }

  if (!sessionJoined) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="max-w-md w-full mx-4 bg-card border border-border rounded-xl p-8">
          <h1 className="text-2xl font-bold text-foreground mb-2">Iniciar Sessão de Suporte</h1>
          <p className="text-muted-foreground mb-6">
            Preencha seus dados para conectar com o técnico de suporte.
          </p>

          <form onSubmit={handleJoinSession} className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Seu Nome *
              </label>
              <input
                type="text"
                placeholder="Ex: João Silva"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-foreground mb-2">
                Email (opcional)
              </label>
              <input
                type="email"
                placeholder="Ex: joao@example.com"
                value={clientEmail}
                onChange={(e) => setClientEmail(e.target.value)}
                className="w-full px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
              disabled={joinSession.isPending}
            >
              {joinSession.isPending ? (
                <>
                  <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                  Conectando...
                </>
              ) : (
                "Conectar"
              )}
            </Button>
          </form>
        </div>
      </div>
    );
  }

  return <SessionContent sessionId={sessionId!} clientName={clientName} />;
}

function SessionContent({ sessionId, clientName }: { sessionId: number; clientName: string }) {
  const [message, setMessage] = useState("");
  const [showHelpDialog, setShowHelpDialog] = useState(false);
  const [activeVideoCall, setActiveVideoCall] = useState<any>(null);

  const { data: messages } = trpc.chat.getMessages.useQuery({ sessionId });

  const sendMessage = trpc.chat.send.useMutation({
    onSuccess: () => {
      setMessage("");
    },
    onError: (error) => {
      toast.error("Erro ao enviar mensagem: " + error.message);
    },
  });

  const createVideoCall = trpc.videoCalls.create.useMutation({
    onSuccess: () => {
      const roomName = `support-${sessionId}-${Date.now()}`;
      setActiveVideoCall({ roomName });
    },
    onError: (error) => {
      toast.error("Erro ao iniciar vídeo: " + error.message);
    },
  });

  const createHelpRequest = trpc.helpRequests.create.useMutation({
    onSuccess: () => {
      setShowHelpDialog(false);
      toast.success("Solicitação de ajuda enviada!");
      
      const roomName = `support-${sessionId}-${Date.now()}`;
      createVideoCall.mutate({
        sessionId,
        jitsiRoomName: roomName,
        peripheralType: "",
        description: "",
      });
    },
    onError: (error) => {
      toast.error("Erro ao criar solicitação: " + error.message);
    },
  });

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) return;
    sendMessage.mutate({ sessionId, content: message });
  };

  const handleCreateHelpRequest = (peripheralType: string, description: string) => {
    createHelpRequest.mutate({ sessionId, peripheralType, description });
  };

  const handleVideoCallEnd = (duration: number) => {
    setActiveVideoCall(null);
    toast.success("Chamada de vídeo encerrada");
  };

  return (
    <div className="min-h-screen bg-background flex flex-col">
      {activeVideoCall && (
        <JitsiMeet
          roomName={activeVideoCall.roomName}
          userName={clientName}
          onClose={() => setActiveVideoCall(null)}
          onCallEnd={handleVideoCallEnd}
        />
      )}

      {showHelpDialog && (
        <HelpRequestDialog
          sessionId={sessionId}
          onClose={() => setShowHelpDialog(false)}
          onSubmit={handleCreateHelpRequest}
          isLoading={createHelpRequest.isPending}
        />
      )}

      <header className="border-b border-border bg-card">
        <div className="max-w-4xl mx-auto px-4 py-4 flex items-center justify-between">
          <div>
            <h1 className="text-xl font-bold text-foreground">Sessão de Suporte</h1>
            <p className="text-sm text-muted-foreground">Conectado como: {clientName}</p>
          </div>
          <Button
            onClick={() => setShowHelpDialog(true)}
            className="bg-accent hover:bg-accent/90 text-accent-foreground flex items-center gap-2"
          >
            <Phone className="w-4 h-4" />
            Solicitar Ajuda
          </Button>
        </div>
      </header>

      <main className="flex-1 max-w-4xl mx-auto w-full px-4 py-8 flex flex-col">
        <div className="flex-1 bg-card border border-border rounded-xl mb-6 p-6 flex flex-col">
          <div className="flex-1 overflow-y-auto space-y-4 mb-6">
            {!messages || messages.length === 0 ? (
              <div className="text-center text-muted-foreground py-8">
                <MessageSquare className="w-12 h-12 mx-auto mb-4 opacity-50" />
                <p>Nenhuma mensagem ainda. Aguarde o técnico conectar.</p>
              </div>
            ) : (
              messages.map((msg) => (
                <div
                  key={msg.id}
                  className={`flex ${msg.senderRole === "client" ? "justify-end" : "justify-start"}`}
                >
                  <div
                    className={`max-w-xs px-4 py-2 rounded-lg ${
                      msg.senderRole === "client"
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-muted-foreground"
                    }`}
                  >
                    <p className="text-sm">{msg.content}</p>
                    <p className="text-xs opacity-70 mt-1">
                      {new Date(msg.createdAt).toLocaleTimeString("pt-BR", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                  </div>
                </div>
              ))
            )}
          </div>

          <form onSubmit={handleSendMessage} className="flex gap-2">
            <input
              type="text"
              placeholder="Digite sua mensagem..."
              value={message}
              onChange={(e) => setMessage(e.target.value)}
              className="flex-1 px-4 py-2 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent"
            />
            <Button
              type="submit"
              disabled={!message.trim() || sendMessage.isPending}
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              <Send className="w-4 h-4" />
            </Button>
          </form>
        </div>

        <div className="bg-muted/50 border border-border rounded-lg p-4 text-sm text-muted-foreground">
          <p>
            O técnico pode compartilhar screenshots anotadas e guiá-lo através de cada passo do suporte. 
            Clique em "Solicitar Ajuda" para iniciar uma videoconferência.
          </p>
        </div>
      </main>
    </div>
  );
}
