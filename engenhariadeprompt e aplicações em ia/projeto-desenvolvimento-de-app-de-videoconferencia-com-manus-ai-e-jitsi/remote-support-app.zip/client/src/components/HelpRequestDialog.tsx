import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { X, AlertCircle } from "lucide-react";
import { toast } from "sonner";

interface HelpRequestDialogProps {
  sessionId: number;
  onClose: () => void;
  onSubmit: (peripheralType: string, description: string) => void;
  isLoading?: boolean;
}

const PERIPHERAL_TYPES = [
  { id: "mouse", label: "Mouse", icon: "🖱️" },
  { id: "keyboard", label: "Teclado", icon: "⌨️" },
  { id: "monitor", label: "Monitor", icon: "🖥️" },
  { id: "webcam", label: "Webcam", icon: "📹" },
  { id: "headset", label: "Headset", icon: "🎧" },
  { id: "printer", label: "Impressora", icon: "🖨️" },
  { id: "usb", label: "Dispositivo USB", icon: "💾" },
  { id: "other", label: "Outro", icon: "❓" },
];

export default function HelpRequestDialog({
  sessionId,
  onClose,
  onSubmit,
  isLoading = false,
}: HelpRequestDialogProps) {
  const [selectedPeripheral, setSelectedPeripheral] = useState<string>("");
  const [description, setDescription] = useState<string>("");

  const handleSubmit = () => {
    if (!selectedPeripheral.trim()) {
      toast.error("Selecione um tipo de periférico");
      return;
    }
    if (!description.trim()) {
      toast.error("Descreva o problema");
      return;
    }

    onSubmit(selectedPeripheral, description);
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl max-w-2xl w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <AlertCircle className="w-6 h-6 text-accent" />
            <h2 className="text-2xl font-bold text-foreground">Solicitar Ajuda</h2>
          </div>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="space-y-6">
          {/* Peripheral Selection */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-3">
              Qual periférico precisa de ajuda?
            </label>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              {PERIPHERAL_TYPES.map((peripheral) => (
                <button
                  key={peripheral.id}
                  onClick={() => setSelectedPeripheral(peripheral.id)}
                  className={`p-4 rounded-lg border-2 transition-all text-center ${
                    selectedPeripheral === peripheral.id
                      ? "border-accent bg-accent/10 text-foreground"
                      : "border-border bg-muted/50 text-muted-foreground hover:border-accent/50"
                  }`}
                >
                  <div className="text-2xl mb-2">{peripheral.icon}</div>
                  <div className="text-sm font-medium">{peripheral.label}</div>
                </button>
              ))}
            </div>
          </div>

          {/* Description */}
          <div>
            <label className="block text-sm font-semibold text-foreground mb-2">
              Descreva o problema
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="Ex: Meu mouse não está funcionando. Preciso de ajuda para conectar um novo..."
              className="w-full px-4 py-3 rounded-lg border border-border bg-background text-foreground placeholder-muted-foreground focus:outline-none focus:ring-2 focus:ring-accent resize-none"
              rows={4}
            />
          </div>

          {/* Actions */}
          <div className="flex gap-3 justify-end">
            <Button
              variant="outline"
              onClick={onClose}
              disabled={isLoading}
            >
              Cancelar
            </Button>
            <Button
              onClick={handleSubmit}
              disabled={isLoading || !selectedPeripheral || !description}
              className="bg-accent hover:bg-accent/90 text-accent-foreground"
            >
              {isLoading ? "Enviando..." : "Solicitar Ajuda com Vídeo"}
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
