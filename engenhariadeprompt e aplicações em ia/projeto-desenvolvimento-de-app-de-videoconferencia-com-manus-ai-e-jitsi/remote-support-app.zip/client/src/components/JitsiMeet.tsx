import React, { useEffect, useRef, useState } from "react";
import { X, Phone, AlertCircle, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";

interface JitsiMeetProps {
  roomName: string;
  userName: string;
  onClose: () => void;
  onCallEnd?: (duration: number) => void;
}

export default function JitsiMeet({ roomName, userName, onClose, onCallEnd }: JitsiMeetProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const jitsiApiRef = useRef<any>(null);
  const startTimeRef = useRef<number>(Date.now());
  const [isLoading, setIsLoading] = useState(true);
  const [hasError, setHasError] = useState(false);

  useEffect(() => {
    const script = document.createElement("script");
    script.src = "https://meet.jitsi.com/external_api.js";
    script.async = true;

    script.onload = () => {
      if (window.JitsiMeetExternalAPI) {
        initializeJitsi();
      } else {
        setHasError(true);
        setIsLoading(false);
      }
    };

    script.onerror = () => {
      setHasError(true);
      setIsLoading(false);
    };

    document.body.appendChild(script);

    return () => {
      if (jitsiApiRef.current) {
        try {
          jitsiApiRef.current.dispose();
        } catch (e) {
          console.error("Error disposing Jitsi API:", e);
        }
        jitsiApiRef.current = null;
      }
      if (script.parentNode) {
        document.body.removeChild(script);
      }
    };
  }, []);

  const initializeJitsi = () => {
    if (!containerRef.current || !window.JitsiMeetExternalAPI) {
      setHasError(true);
      setIsLoading(false);
      return;
    }

    try {
      const options = {
        roomName: roomName,
        width: "100%",
        height: "100%",
        parentNode: containerRef.current,
        userInfo: {
          displayName: userName,
        },
        configOverwrite: {
          startAudioOnly: false,
          disableAudioLevels: true,
          enableWelcomePage: false,
          enableClosePage: false,
        },
        interfaceConfigOverwrite: {
          DEFAULT_BACKGROUND: "#000000",
          SHOW_JITSI_WATERMARK: false,
          SHOW_WATERMARK_FOR_GUESTS: false,
          TOOLBAR_BUTTONS: [
            "microphone",
            "camera",
            "closedcaptions",
            "desktop",
            "fullscreen",
            "fodeviceselection",
            "hangup",
            "profile",
            "chat",
            "recording",
            "livestreaming",
            "etherpad",
            "sharedvideo",
            "settings",
            "raisehand",
            "videoquality",
            "filmstrip",
            "invite",
            "feedback",
            "stats",
            "shortcuts",
            "tileview",
            "download",
            "help",
            "mute-everyone",
            "security",
          ],
        },
      };

      jitsiApiRef.current = new window.JitsiMeetExternalAPI("meet.jitsi.com", options);

      jitsiApiRef.current.addEventListener("videoConferenceJoined", () => {
        console.log("Video conference joined");
        setIsLoading(false);
      });

      jitsiApiRef.current.addEventListener("videoConferenceLeft", () => {
        const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
        if (onCallEnd) {
          onCallEnd(duration);
        }
      });

      jitsiApiRef.current.addEventListener("participantJoined", (participant: any) => {
        console.log("Participant joined:", participant);
      });

      jitsiApiRef.current.addEventListener("participantLeft", (participant: any) => {
        console.log("Participant left:", participant);
      });

      jitsiApiRef.current.addEventListener("readyToClose", () => {
        const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
        if (onCallEnd) {
          onCallEnd(duration);
        }
        onClose();
      });
    } catch (error) {
      console.error("Error initializing Jitsi Meet:", error);
      setHasError(true);
      setIsLoading(false);
    }
  };

  const handleEndCall = () => {
    if (jitsiApiRef.current) {
      try {
        jitsiApiRef.current.executeCommand("hangup");
      } catch (e) {
        console.error("Error hanging up:", e);
      }
    }
    const duration = Math.floor((Date.now() - startTimeRef.current) / 1000);
    if (onCallEnd) {
      onCallEnd(duration);
    }
    onClose();
  };

  if (hasError) {
    return (
      <div className="fixed inset-0 bg-black z-50 flex flex-col">
        <div className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
          <h2 className="text-xl font-bold text-foreground">Videoconferência</h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        <div className="flex-1 flex items-center justify-center">
          <div className="text-center">
            <AlertCircle className="w-12 h-12 text-destructive mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-foreground mb-2">Erro ao carregar Jitsi Meet</h3>
            <p className="text-muted-foreground mb-6">
              Não foi possível carregar a plataforma de videoconferência. Tente novamente mais tarde.
            </p>
            <Button onClick={onClose} className="bg-accent hover:bg-accent/90 text-accent-foreground">
              Fechar
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-black z-50 flex flex-col">
      <div className="bg-card border-b border-border px-6 py-4 flex items-center justify-between">
        <div>
          <h2 className="text-xl font-bold text-foreground">Videoconferência</h2>
          <p className="text-sm text-muted-foreground">Sala: {roomName}</p>
        </div>
        <div className="flex gap-3">
          <Button
            onClick={handleEndCall}
            className="bg-red-600 hover:bg-red-700 text-white"
          >
            <Phone className="w-4 h-4 mr-2" />
            Encerrar Chamada
          </Button>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-hidden relative">
        {isLoading && (
          <div className="absolute inset-0 bg-black/80 flex items-center justify-center z-10">
            <div className="flex flex-col items-center gap-4">
              <Loader2 className="w-8 h-8 animate-spin text-accent" />
              <p className="text-muted-foreground">Conectando à sala de videoconferência...</p>
            </div>
          </div>
        )}
        <div ref={containerRef} className="w-full h-full" />
      </div>
    </div>
  );
}

declare global {
  interface Window {
    JitsiMeetExternalAPI: any;
  }
}
