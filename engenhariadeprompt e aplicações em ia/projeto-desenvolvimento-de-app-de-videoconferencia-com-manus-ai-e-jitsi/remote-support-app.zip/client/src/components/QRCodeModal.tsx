import React, { useState } from "react";
import { X, Share2, Download } from "lucide-react";
import { Button } from "@/components/ui/button";
import QRCode from "react-qr-code";
import { toast } from "sonner";

interface QRCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  url?: string;
}

export default function QRCodeModal({ isOpen, onClose, url = "https://remotesupp-rsbvhcp7.manus.space" }: QRCodeModalProps) {
  const [copied, setCopied] = useState(false);

  const handleCopyLink = () => {
    navigator.clipboard.writeText(url);
    setCopied(true);
    toast.success("Link copiado para a área de transferência!");
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadQR = () => {
    const svg = document.getElementById("qrcode-svg");
    if (!svg) return;

    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const svgData = new XMLSerializer().serializeToString(svg);
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      const link = document.createElement("a");
      link.href = canvas.toDataURL("image/png");
      link.download = "qrcode-suporte-remoto.png";
      link.click();
      toast.success("QR Code baixado com sucesso!");
    };
    img.src = "data:image/svg+xml;base64," + btoa(svgData);
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl max-w-md w-full p-8 relative">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-4 right-4 text-muted-foreground hover:text-foreground transition-colors"
        >
          <X className="w-6 h-6" />
        </button>

        {/* Header */}
        <div className="mb-6">
          <h2 className="text-2xl font-bold text-foreground flex items-center gap-2">
            <Share2 className="w-6 h-6 text-accent" />
            Compartilhar Plataforma
          </h2>
          <p className="text-sm text-muted-foreground mt-2">
            Escaneie o QR Code ou compartilhe o link abaixo para acessar a plataforma
          </p>
        </div>

        {/* QR Code */}
        <div className="flex justify-center mb-6 p-4 bg-white rounded-lg">
          <QRCode
            value={url}
            size={256}
            level="H"
            fgColor="#000000"
            bgColor="#ffffff"
          />
        </div>

        {/* URL Display */}
        <div className="mb-6 p-4 bg-muted rounded-lg border border-border">
          <p className="text-xs text-muted-foreground mb-2">Link de Acesso:</p>
          <p className="text-sm font-mono text-foreground break-all">{url}</p>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button
            onClick={handleCopyLink}
            className="w-full bg-accent hover:bg-accent/90 text-accent-foreground"
          >
            {copied ? "✓ Link Copiado" : "Copiar Link"}
          </Button>
          <Button
            onClick={handleDownloadQR}
            variant="outline"
            className="w-full"
          >
            <Download className="w-4 h-4 mr-2" />
            Baixar QR Code
          </Button>
          <Button
            onClick={onClose}
            variant="ghost"
            className="w-full"
          >
            Fechar
          </Button>
        </div>

        {/* Info */}
        <div className="mt-6 p-4 bg-blue-50 border border-blue-200 rounded-lg">
          <p className="text-xs text-blue-900">
            💡 <strong>Dica:</strong> Compartilhe este QR Code com seus clientes ou colegas para que eles possam acessar a plataforma rapidamente!
          </p>
        </div>
      </div>
    </div>
  );
}
