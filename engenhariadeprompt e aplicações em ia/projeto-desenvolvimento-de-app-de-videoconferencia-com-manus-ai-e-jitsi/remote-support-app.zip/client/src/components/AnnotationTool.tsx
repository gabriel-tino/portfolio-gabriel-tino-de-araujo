import React, { useRef, useEffect, useState } from "react";
import {
  Pen,
  ArrowRight,
  Square,
  Circle,
  Type,
  Undo2,
  Download,
  X,
  Palette,
} from "lucide-react";
import { Button } from "./ui/button";

interface DrawingAction {
  type: "freehand" | "arrow" | "rectangle" | "circle" | "line" | "text";
  data: any;
  color: string;
  strokeWidth: number;
}

interface AnnotationToolProps {
  imageUrl: string;
  onClose: () => void;
  onSave: (canvas: HTMLCanvasElement, annotations: DrawingAction[]) => void;
}

export default function AnnotationTool({
  imageUrl,
  onClose,
  onSave,
}: AnnotationToolProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [isDrawing, setIsDrawing] = useState(false);
  const [tool, setTool] = useState<DrawingAction["type"]>("freehand");
  const [color, setColor] = useState("#000000");
  const [strokeWidth, setStrokeWidth] = useState(2);
  const [actions, setActions] = useState<DrawingAction[]>([]);
  const [startPoint, setStartPoint] = useState<{ x: number; y: number } | null>(null);

  // Load image and setup canvas
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const img = new Image();
    img.onload = () => {
      canvas.width = img.width;
      canvas.height = img.height;
      ctx.drawImage(img, 0, 0);
      redrawAnnotations();
    };
    img.src = imageUrl;
  }, [imageUrl]);

  const redrawAnnotations = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    // Redraw image
    const img = new Image();
    img.onload = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0);

      // Redraw all annotations
      actions.forEach((action) => {
        drawAnnotation(ctx, action);
      });
    };
    img.src = imageUrl;
  };

  const drawAnnotation = (ctx: CanvasRenderingContext2D, action: DrawingAction) => {
    ctx.strokeStyle = action.color;
    ctx.fillStyle = action.color;
    ctx.lineWidth = action.strokeWidth;
    ctx.lineCap = "round";
    ctx.lineJoin = "round";

    switch (action.type) {
      case "freehand":
        ctx.beginPath();
        ctx.moveTo(action.data.points[0].x, action.data.points[0].y);
        action.data.points.forEach((point: any) => {
          ctx.lineTo(point.x, point.y);
        });
        ctx.stroke();
        break;

      case "arrow":
        drawArrow(ctx, action.data.from, action.data.to, action.color, action.strokeWidth);
        break;

      case "rectangle":
        ctx.strokeRect(
          action.data.x,
          action.data.y,
          action.data.width,
          action.data.height
        );
        break;

      case "circle":
        ctx.beginPath();
        ctx.arc(action.data.cx, action.data.cy, action.data.r, 0, 2 * Math.PI);
        ctx.stroke();
        break;

      case "line":
        ctx.beginPath();
        ctx.moveTo(action.data.from.x, action.data.from.y);
        ctx.lineTo(action.data.to.x, action.data.to.y);
        ctx.stroke();
        break;

      case "text":
        ctx.font = `${action.strokeWidth * 8}px Arial`;
        ctx.fillText(action.data.text, action.data.x, action.data.y);
        break;
    }
  };

  const drawArrow = (
    ctx: CanvasRenderingContext2D,
    from: { x: number; y: number },
    to: { x: number; y: number },
    color: string,
    width: number
  ) => {
    const headlen = 15;
    const angle = Math.atan2(to.y - from.y, to.x - from.x);

    ctx.strokeStyle = color;
    ctx.fillStyle = color;
    ctx.lineWidth = width;

    // Draw line
    ctx.beginPath();
    ctx.moveTo(from.x, from.y);
    ctx.lineTo(to.x, to.y);
    ctx.stroke();

    // Draw arrowhead
    ctx.beginPath();
    ctx.moveTo(to.x, to.y);
    ctx.lineTo(to.x - headlen * Math.cos(angle - Math.PI / 6), to.y - headlen * Math.sin(angle - Math.PI / 6));
    ctx.lineTo(to.x - headlen * Math.cos(angle + Math.PI / 6), to.y - headlen * Math.sin(angle + Math.PI / 6));
    ctx.closePath();
    ctx.fill();
  };

  const handleMouseDown = (e: React.MouseEvent<HTMLCanvasElement>) => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    setIsDrawing(true);
    setStartPoint({ x, y });

    if (tool === "freehand") {
      setActions([
        ...actions,
        {
          type: "freehand",
          data: { points: [{ x, y }] },
          color,
          strokeWidth,
        },
      ]);
    }
  };

  const handleMouseMove = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !canvasRef.current) return;

    const canvas = canvasRef.current;
    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (tool === "freehand" && actions.length > 0) {
      const lastAction = actions[actions.length - 1];
      if (lastAction.type === "freehand") {
        lastAction.data.points.push({ x, y });
        redrawAnnotations();

        // Draw current point
        ctx.strokeStyle = color;
        ctx.lineWidth = strokeWidth;
        ctx.lineCap = "round";
        ctx.lineJoin = "round";
        ctx.beginPath();
        const points = lastAction.data.points;
        ctx.moveTo(points[points.length - 2].x, points[points.length - 2].y);
        ctx.lineTo(x, y);
        ctx.stroke();
      }
    }
  };

  const handleMouseUp = (e: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDrawing || !startPoint) return;

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    const newAction: DrawingAction = {
      type: tool,
      data: {},
      color,
      strokeWidth,
    };

    switch (tool) {
      case "arrow":
      case "line":
        newAction.data = { from: startPoint, to: { x, y } };
        setActions([...actions, newAction]);
        break;

      case "rectangle":
        newAction.data = {
          x: Math.min(startPoint.x, x),
          y: Math.min(startPoint.y, y),
          width: Math.abs(x - startPoint.x),
          height: Math.abs(y - startPoint.y),
        };
        setActions([...actions, newAction]);
        break;

      case "circle":
        const radius = Math.sqrt(
          Math.pow(x - startPoint.x, 2) + Math.pow(y - startPoint.y, 2)
        );
        newAction.data = { cx: startPoint.x, cy: startPoint.y, r: radius };
        setActions([...actions, newAction]);
        break;
    }

    setIsDrawing(false);
    setStartPoint(null);
    redrawAnnotations();
  };

  const handleUndo = () => {
    const newActions = actions.slice(0, -1);
    setActions(newActions);
    setTimeout(redrawAnnotations, 0);
  };

  const handleTextInput = () => {
    const text = prompt("Digite o texto:");
    if (text && startPoint) {
      setActions([
        ...actions,
        {
          type: "text",
          data: { text, x: startPoint.x, y: startPoint.y },
          color,
          strokeWidth,
        },
      ]);
      redrawAnnotations();
      setStartPoint(null);
    }
  };

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl overflow-hidden max-w-4xl w-full max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="border-b border-border px-6 py-4 flex items-center justify-between">
          <h2 className="text-lg font-semibold text-foreground">Ferramenta de Anotação</h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Toolbar */}
        <div className="border-b border-border px-6 py-3 flex items-center gap-2 flex-wrap bg-muted/30">
          <div className="flex items-center gap-1 border-r border-border pr-3">
            <ToolButton
              icon={Pen}
              label="Desenho"
              active={tool === "freehand"}
              onClick={() => setTool("freehand")}
            />
            <ToolButton
              icon={ArrowRight}
              label="Seta"
              active={tool === "arrow"}
              onClick={() => setTool("arrow")}
            />
            <ToolButton
              icon={Square}
              label="Retângulo"
              active={tool === "rectangle"}
              onClick={() => setTool("rectangle")}
            />
            <ToolButton
              icon={Circle}
              label="Círculo"
              active={tool === "circle"}
              onClick={() => setTool("circle")}
            />
            <ToolButton
              icon={Type}
              label="Texto"
              active={tool === "text"}
              onClick={handleTextInput}
            />
          </div>

          <div className="flex items-center gap-3 border-r border-border pr-3">
            <div className="flex items-center gap-2">
              <Palette className="w-4 h-4 text-muted-foreground" />
              <input
                type="color"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                className="w-8 h-8 rounded cursor-pointer"
              />
            </div>

            <div className="flex items-center gap-2">
              <label className="text-sm text-muted-foreground">Espessura:</label>
              <input
                type="range"
                min="1"
                max="10"
                value={strokeWidth}
                onChange={(e) => setStrokeWidth(Number(e.target.value))}
                className="w-20"
              />
              <span className="text-sm text-muted-foreground">{strokeWidth}px</span>
            </div>
          </div>

          <div className="flex items-center gap-2 ml-auto">
            <Button
              variant="outline"
              size="sm"
              onClick={handleUndo}
              disabled={actions.length === 0}
            >
              <Undo2 className="w-4 h-4 mr-2" />
              Desfazer
            </Button>
            <Button
              variant="outline"
              size="sm"
              onClick={() => {
                const canvas = canvasRef.current;
                if (canvas) {
                  const link = document.createElement("a");
                  link.href = canvas.toDataURL();
                  link.download = `anotacao-${Date.now()}.png`;
                  link.click();
                }
              }}
            >
              <Download className="w-4 h-4 mr-2" />
              Baixar
            </Button>
          </div>
        </div>

        {/* Canvas Area */}
        <div className="flex-1 overflow-auto bg-black/20 flex items-center justify-center p-4">
          <canvas
            ref={canvasRef}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
            onMouseLeave={handleMouseUp}
            className="max-w-full max-h-full border border-border rounded cursor-crosshair bg-white"
          />
        </div>

        {/* Footer */}
        <div className="border-t border-border px-6 py-4 flex items-center justify-end gap-3">
          <Button variant="outline" onClick={onClose}>
            Cancelar
          </Button>
          <Button
            className="bg-accent hover:bg-accent/90 text-accent-foreground"
            onClick={() => {
              const canvas = canvasRef.current;
              if (canvas) {
                onSave(canvas, actions);
              }
            }}
          >
            Salvar Anotações
          </Button>
        </div>
      </div>
    </div>
  );
}

function ToolButton({
  icon: Icon,
  label,
  active,
  onClick,
}: {
  icon: React.ComponentType<{ className?: string }>;
  label: string;
  active: boolean;
  onClick: () => void;
}) {
  return (
    <button
      onClick={onClick}
      title={label}
      className={`p-2 rounded transition-colors ${
        active
          ? "bg-accent text-accent-foreground"
          : "text-muted-foreground hover:text-foreground hover:bg-muted"
      }`}
    >
      <Icon className="w-4 h-4" />
    </button>
  );
}
