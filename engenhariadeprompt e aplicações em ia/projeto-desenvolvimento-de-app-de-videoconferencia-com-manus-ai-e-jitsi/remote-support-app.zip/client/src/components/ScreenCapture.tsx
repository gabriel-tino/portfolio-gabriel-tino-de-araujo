import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Monitor, X, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface ScreenCaptureProps {
  onCapture: (imageUrl: string) => void;
  onClose: () => void;
}

export default function ScreenCapture({ onCapture, onClose }: ScreenCaptureProps) {
  const [isCapturing, setIsCapturing] = useState(false);
  const [capturedImage, setCapturedImage] = useState<string | null>(null);

  const captureScreen = async () => {
    setIsCapturing(true);
    try {
      const canvas = await html2canvas(document.documentElement);
      const imageUrl = canvas.toDataURL("image/png");
      setCapturedImage(imageUrl);
      toast.success("Tela capturada com sucesso!");
    } catch (error) {
      console.error("Erro ao capturar tela:", error);
      toast.error("Erro ao capturar tela. Tente novamente.");
    } finally {
      setIsCapturing(false);
    }
  };

  const handleConfirm = () => {
    if (capturedImage) {
      onCapture(capturedImage);
      onClose();
    }
  };

  const handleRetake = () => {
    setCapturedImage(null);
  };

  return (
    <div className="fixed inset-0 bg-black/80 z-50 flex items-center justify-center p-4">
      <div className="bg-card border border-border rounded-xl max-w-2xl w-full p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold text-foreground">Capturar Tela</h2>
          <button
            onClick={onClose}
            className="text-muted-foreground hover:text-foreground transition-colors"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {!capturedImage ? (
          <div className="space-y-6">
            <div className="bg-muted/50 rounded-lg p-8 text-center">
              <Monitor className="w-16 h-16 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground mb-4">
                Clique no botão abaixo para capturar sua tela
              </p>
              <Button
                onClick={captureScreen}
                disabled={isCapturing}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                {isCapturing ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Capturando...
                  </>
                ) : (
                  <>
                    <Monitor className="w-4 h-4 mr-2" />
                    Capturar Tela
                  </>
                )}
              </Button>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-muted/50 rounded-lg overflow-hidden">
              <img
                src={capturedImage}
                alt="Captura de tela"
                className="w-full max-h-96 object-contain"
              />
            </div>
            <div className="flex gap-3 justify-end">
              <Button
                variant="outline"
                onClick={handleRetake}
              >
                Capturar Novamente
              </Button>
              <Button
                onClick={handleConfirm}
                className="bg-accent hover:bg-accent/90 text-accent-foreground"
              >
                Usar Esta Captura
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// Função auxiliar para captura de tela usando html2canvas
// Você pode instalar com: pnpm add html2canvas
async function html2canvas(element: HTMLElement): Promise<HTMLCanvasElement> {
  const canvas = document.createElement("canvas");
  const ctx = canvas.getContext("2d");

  if (!ctx) {
    throw new Error("Não foi possível obter contexto 2D do canvas");
  }

  // Usar dimensões da viewport
  const width = window.innerWidth;
  const height = window.innerHeight;

  canvas.width = width;
  canvas.height = height;

  // Preencher com branco
  ctx.fillStyle = "#FFFFFF";
  ctx.fillRect(0, 0, width, height);

  // Renderizar elemento
  try {
    const svgString = new XMLSerializer().serializeToString(element);
    const img = new Image();
    img.onload = () => {
      ctx.drawImage(img, 0, 0);
    };
    img.src = "data:image/svg+xml;base64," + btoa(svgString);
  } catch (error) {
    // Fallback: usar screenshot simples
    ctx.fillStyle = "#f0f0f0";
    ctx.font = "16px Arial";
    ctx.fillText("Captura de tela não disponível neste navegador", 20, 30);
  }

  return canvas;
}
