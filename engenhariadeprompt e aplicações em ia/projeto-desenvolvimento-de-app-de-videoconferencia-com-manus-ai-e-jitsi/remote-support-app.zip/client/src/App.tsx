import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import { useAuth } from "./_core/hooks/useAuth";
import { Loader2, Share2 } from "lucide-react";
import TechnicianDashboard from "./pages/TechnicianDashboard";
import ClientSession from "./pages/ClientSession";
import SessionDetail from "./pages/SessionDetail";
import QRCodeModal from "./components/QRCodeModal";
import { useState } from "react";

function Router() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-accent" />
          <p className="text-muted-foreground">Carregando...</p>
        </div>
      </div>
    );
  }

  return (
    <Switch>
      {/* Public routes */}
      <Route path={"/"} component={Home} />
      <Route path={"/client/:accessCode"} component={ClientSession} />

      {/* Technician routes */}
      {user?.role === "admin" && (
        <>
          <Route path={"/dashboard"} component={TechnicianDashboard} />
          <Route path={"/session/:id"} component={SessionDetail} />
        </>
      )}

      {/* Fallback */}
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [showQRModal, setShowQRModal] = useState(false);

  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <TooltipProvider>
          <Toaster />
          
          {/* QR Code Modal */}
          <QRCodeModal 
            isOpen={showQRModal} 
            onClose={() => setShowQRModal(false)}
            url="https://remotesupp-rsbvhcp7.manus.space"
          />

          {/* Share Button - Fixed Position */}
          <button
            onClick={() => setShowQRModal(true)}
            className="fixed bottom-6 right-6 z-40 bg-accent hover:bg-accent/90 text-accent-foreground p-4 rounded-full shadow-lg transition-all duration-200 hover:scale-110 flex items-center justify-center"
            title="Compartilhar QR Code"
          >
            <Share2 className="w-6 h-6" />
          </button>

          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
