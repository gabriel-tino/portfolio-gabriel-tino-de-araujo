CREATE TABLE `help_requests` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`client_id` int NOT NULL,
	`peripheral_type` varchar(100) NOT NULL,
	`description` text NOT NULL,
	`status` enum('pending','accepted','in_progress','completed','rejected') NOT NULL DEFAULT 'pending',
	`video_call_id` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `help_requests_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `video_calls` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`initiated_by` int NOT NULL,
	`initiated_by_role` enum('technician','client') NOT NULL,
	`status` enum('pending','accepted','active','completed','rejected','cancelled') NOT NULL DEFAULT 'pending',
	`jitsi_room_name` varchar(255) NOT NULL,
	`peripheral_type` varchar(100),
	`description` text,
	`started_at` timestamp,
	`ended_at` timestamp,
	`duration` int,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `video_calls_id` PRIMARY KEY(`id`)
);
