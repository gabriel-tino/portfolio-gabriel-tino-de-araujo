import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, json, boolean } from "drizzle-orm/mysql-core";
import { relations } from "drizzle-orm";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Support sessions table - tracks all support sessions between technician and client
 */
export const supportSessions = mysqlTable("support_sessions", {
  id: int("id").autoincrement().primaryKey(),
  accessCode: varchar("access_code", { length: 12 }).notNull().unique(), // Unique code for client access
  technicianId: int("technician_id").notNull(), // Reference to technician (admin user)
  clientId: int("client_id"), // Reference to client (user) - null until client joins
  clientName: varchar("client_name", { length: 255 }), // Client name if not registered
  clientEmail: varchar("client_email", { length: 320 }), // Client email
  status: mysqlEnum("status", ["pending", "active", "completed", "cancelled"]).default("pending").notNull(),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type SupportSession = typeof supportSessions.$inferSelect;
export type InsertSupportSession = typeof supportSessions.$inferInsert;

/**
 * Chat messages table - stores all messages exchanged during a session
 */
export const chatMessages = mysqlTable("chat_messages", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  senderId: int("sender_id").notNull(),
  senderRole: mysqlEnum("sender_role", ["technician", "client"]).notNull(),
  content: text("content").notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type ChatMessage = typeof chatMessages.$inferSelect;
export type InsertChatMessage = typeof chatMessages.$inferInsert;

/**
 * Annotations table - stores all screen annotations made by technician
 */
export const annotations = mysqlTable("annotations", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  screenshotId: int("screenshot_id"),
  type: mysqlEnum("type", ["freehand", "arrow", "rectangle", "circle", "line", "text"]).notNull(),
  data: json("data").notNull(), // Stores drawing data as JSON
  color: varchar("color", { length: 7 }).default("#000000").notNull(),
  strokeWidth: int("stroke_width").default(2).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Annotation = typeof annotations.$inferSelect;
export type InsertAnnotation = typeof annotations.$inferInsert;

/**
 * Screenshots table - stores screenshots shared during sessions
 */
export const screenshots = mysqlTable("screenshots", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  uploadedBy: int("uploaded_by").notNull(), // User who uploaded the screenshot
  uploadedByRole: mysqlEnum("uploaded_by_role", ["technician", "client"]).notNull(),
  storageUrl: varchar("storage_url", { length: 500 }).notNull(), // URL to the screenshot in storage
  storageKey: varchar("storage_key", { length: 500 }).notNull(), // Storage key for reference
  originalFileName: varchar("original_file_name", { length: 255 }),
  hasAnnotations: boolean("has_annotations").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type Screenshot = typeof screenshots.$inferSelect;
export type InsertScreenshot = typeof screenshots.$inferInsert;

/**
 * Session history table - maintains complete history of sessions for archival
 */
export const sessionHistory = mysqlTable("session_history", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  technicianId: int("technician_id").notNull(),
  clientId: int("client_id"),
  clientName: varchar("client_name", { length: 255 }),
  clientEmail: varchar("client_email", { length: 320 }),
  totalDuration: int("total_duration"), // Duration in seconds
  messageCount: int("message_count").default(0).notNull(),
  screenshotCount: int("screenshot_count").default(0).notNull(),
  annotationCount: int("annotation_count").default(0).notNull(),
  notes: text("notes"), // Additional notes from technician
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export type SessionHistory = typeof sessionHistory.$inferSelect;
export type InsertSessionHistory = typeof sessionHistory.$inferInsert;

/**
 * Video calls table - stores all video conference sessions
 */
export const videoCalls = mysqlTable("video_calls", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  initiatedBy: int("initiated_by").notNull(),
  initiatedByRole: mysqlEnum("initiated_by_role", ["technician", "client"]).notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "active", "completed", "rejected", "cancelled"]).default("pending").notNull(),
  jitsiRoomName: varchar("jitsi_room_name", { length: 255 }).notNull(),
  peripheralType: varchar("peripheral_type", { length: 100 }),
  description: text("description"),
  startedAt: timestamp("started_at"),
  endedAt: timestamp("ended_at"),
  duration: int("duration"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type VideoCall = typeof videoCalls.$inferSelect;
export type InsertVideoCall = typeof videoCalls.$inferInsert;

/**
 * Help requests table - tracks requests for help with peripherals
 */
export const helpRequests = mysqlTable("help_requests", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: int("session_id").notNull(),
  clientId: int("client_id").notNull(),
  peripheralType: varchar("peripheral_type", { length: 100 }).notNull(),
  description: text("description").notNull(),
  status: mysqlEnum("status", ["pending", "accepted", "in_progress", "completed", "rejected"]).default("pending").notNull(),
  videoCallId: int("video_call_id"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().onUpdateNow().notNull(),
});

export type HelpRequest = typeof helpRequests.$inferSelect;
export type InsertHelpRequest = typeof helpRequests.$inferInsert;
