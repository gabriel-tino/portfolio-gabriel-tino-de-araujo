CREATE TABLE `annotations` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`screenshot_id` int,
	`type` enum('freehand','arrow','rectangle','circle','line','text') NOT NULL,
	`data` json NOT NULL,
	`color` varchar(7) NOT NULL DEFAULT '#000000',
	`stroke_width` int NOT NULL DEFAULT 2,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `annotations_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `chat_messages` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`sender_id` int NOT NULL,
	`sender_role` enum('technician','client') NOT NULL,
	`content` text NOT NULL,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `chat_messages_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `screenshots` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`uploaded_by` int NOT NULL,
	`uploaded_by_role` enum('technician','client') NOT NULL,
	`storage_url` varchar(500) NOT NULL,
	`storage_key` varchar(500) NOT NULL,
	`original_file_name` varchar(255),
	`has_annotations` boolean NOT NULL DEFAULT false,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `screenshots_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `session_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`session_id` int NOT NULL,
	`technician_id` int NOT NULL,
	`client_id` int,
	`client_name` varchar(255),
	`client_email` varchar(320),
	`total_duration` int,
	`message_count` int NOT NULL DEFAULT 0,
	`screenshot_count` int NOT NULL DEFAULT 0,
	`annotation_count` int NOT NULL DEFAULT 0,
	`notes` text,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `session_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `support_sessions` (
	`id` int AUTO_INCREMENT NOT NULL,
	`access_code` varchar(12) NOT NULL,
	`technician_id` int NOT NULL,
	`client_id` int,
	`client_name` varchar(255),
	`client_email` varchar(320),
	`status` enum('pending','active','completed','cancelled') NOT NULL DEFAULT 'pending',
	`started_at` timestamp,
	`ended_at` timestamp,
	`created_at` timestamp NOT NULL DEFAULT (now()),
	`updated_at` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `support_sessions_id` PRIMARY KEY(`id`),
	CONSTRAINT `support_sessions_access_code_unique` UNIQUE(`access_code`)
);
