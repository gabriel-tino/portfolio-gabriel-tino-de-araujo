import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

// Mock context for technician
function createTechnicianContext(): TrpcContext {
  return {
    user: {
      id: 1,
      openId: "tech-user-1",
      email: "tech@example.com",
      name: "Technician",
      loginMethod: "manus",
      role: "admin",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

// Mock context for client
function createClientContext(): TrpcContext {
  return {
    user: {
      id: 2,
      openId: "client-user-1",
      email: "client@example.com",
      name: "Client",
      loginMethod: "manus",
      role: "user",
      createdAt: new Date(),
      updatedAt: new Date(),
      lastSignedIn: new Date(),
    },
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("Support Sessions", () => {
  let techContext: TrpcContext;

  beforeEach(() => {
    techContext = createTechnicianContext();
  });

  it("technician can create a support session", async () => {
    const caller = appRouter.createCaller(techContext);

    const result = await caller.sessions.create({
      clientName: "John Doe",
      clientEmail: "john@example.com",
    });

    expect(result).toHaveProperty("accessCode");
    expect(result).toHaveProperty("success", true);
    expect(result.accessCode).toMatch(/^[A-Z0-9]{6}$/);
  });

  it("non-admin user cannot create a support session", async () => {
    const clientContext = createClientContext();
    const caller = appRouter.createCaller(clientContext);

    try {
      await caller.sessions.create({
        clientName: "John Doe",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("can retrieve session by access code", async () => {
    const techCaller = appRouter.createCaller(techContext);

    // Create a session
    const created = await techCaller.sessions.create({
      clientName: "Jane Doe",
    });

    // Retrieve it
    const publicCaller = appRouter.createCaller({
      user: null,
      req: { protocol: "https", headers: {} } as TrpcContext["req"],
      res: {} as TrpcContext["res"],
    });

    const session = await publicCaller.sessions.getByAccessCode({
      accessCode: created.accessCode,
    });

    expect(session).toBeDefined();
    expect(session?.accessCode).toBe(created.accessCode);
    expect(session?.clientName).toBe("Jane Doe");
  });
});

describe("Chat", () => {
  let techContext: TrpcContext;

  beforeEach(() => {
    techContext = createTechnicianContext();
  });

  it("technician can send a message", async () => {
    const caller = appRouter.createCaller(techContext);

    // This would normally require a valid sessionId from the database
    // For testing purposes, we're testing the structure
    const result = await caller.chat.send({
      sessionId: 1,
      content: "Hello client!",
    });

    expect(result).toHaveProperty("success", true);
  });

  it("can retrieve chat messages for a session", async () => {
    const caller = appRouter.createCaller(techContext);

    const messages = await caller.chat.getMessages({
      sessionId: 1,
    });

    expect(Array.isArray(messages)).toBe(true);
  });
});

describe("Media Management", () => {
  let techContext: TrpcContext;

  beforeEach(() => {
    techContext = createTechnicianContext();
  });

  it("technician can upload a screenshot", async () => {
    const caller = appRouter.createCaller(techContext);

    const result = await caller.media.uploadScreenshot({
      sessionId: 1,
      storageUrl: "https://example.com/screenshot.png",
      storageKey: "screenshots/session-1/img-123.png",
      originalFileName: "screenshot.png",
    });

    expect(result).toHaveProperty("success", true);
  });

  it("can retrieve screenshots for a session", async () => {
    const caller = appRouter.createCaller(techContext);

    const screenshots = await caller.media.getScreenshots({
      sessionId: 1,
    });

    expect(Array.isArray(screenshots)).toBe(true);
  });

  it("technician can add an annotation", async () => {
    const caller = appRouter.createCaller(techContext);

    const result = await caller.media.addAnnotation({
      sessionId: 1,
      type: "freehand",
      data: { points: [{ x: 10, y: 20 }, { x: 30, y: 40 }] },
      color: "#FF0000",
      strokeWidth: 2,
    });

    expect(result).toHaveProperty("success", true);
  });

  it("can retrieve annotations for a session", async () => {
    const caller = appRouter.createCaller(techContext);

    const annotations = await caller.media.getAnnotations({
      sessionId: 1,
    });

    expect(Array.isArray(annotations)).toBe(true);
  });
});

describe("Session Status", () => {
  let techContext: TrpcContext;

  beforeEach(() => {
    techContext = createTechnicianContext();
  });

  it("technician can update session status", async () => {
    const caller = appRouter.createCaller(techContext);

    const result = await caller.sessions.updateStatus({
      sessionId: 1,
      status: "active",
    });

    expect(result).toHaveProperty("success", true);
  });

  it("non-admin cannot update session status", async () => {
    const clientContext = createClientContext();
    const caller = appRouter.createCaller(clientContext);

    try {
      await caller.sessions.updateStatus({
        sessionId: 1,
        status: "active",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });
});
