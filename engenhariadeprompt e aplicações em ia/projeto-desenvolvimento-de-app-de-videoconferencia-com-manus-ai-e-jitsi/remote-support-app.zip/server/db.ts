import { eq } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  supportSessions,
  chatMessages,
  screenshots,
  annotations,
  sessionHistory,
  videoCalls,
  helpRequests,
  type VideoCall,
  type HelpRequest,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

/**
 * Support Sessions Queries
 */
export async function createSupportSession(
  technicianId: number,
  accessCode: string,
  clientName?: string,
  clientEmail?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(supportSessions).values({
    technicianId,
    accessCode,
    clientName,
    clientEmail,
    status: "pending",
  });

  return result;
}

export async function getSupportSessionByAccessCode(accessCode: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(supportSessions)
    .where(eq(supportSessions.accessCode, accessCode))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getSupportSessionById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(supportSessions)
    .where(eq(supportSessions.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getTechnicianSessions(technicianId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(supportSessions)
    .where(eq(supportSessions.technicianId, technicianId));
}

export async function updateSessionStatus(
  sessionId: number,
  status: "pending" | "active" | "completed" | "cancelled"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (status === "active") {
    updateData.startedAt = new Date();
  } else if (status === "completed" || status === "cancelled") {
    updateData.endedAt = new Date();
  }

  return await db
    .update(supportSessions)
    .set(updateData)
    .where(eq(supportSessions.id, sessionId));
}

export async function joinSessionAsClient(
  sessionId: number,
  clientId?: number,
  clientName?: string,
  clientEmail?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(supportSessions)
    .set({
      clientId: clientId || undefined,
      clientName,
      clientEmail,
      status: "active",
      startedAt: new Date(),
    })
    .where(eq(supportSessions.id, sessionId));
}

/**
 * Chat Messages Queries
 */
export async function addChatMessage(
  sessionId: number,
  senderId: number,
  senderRole: "technician" | "client",
  content: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(chatMessages).values({
    sessionId,
    senderId,
    senderRole,
    content,
  });
}

export async function getSessionMessages(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(chatMessages)
    .where(eq(chatMessages.sessionId, sessionId));
}

/**
 * Screenshots Queries
 */
export async function addScreenshot(
  sessionId: number,
  uploadedBy: number,
  uploadedByRole: "technician" | "client",
  storageUrl: string,
  storageKey: string,
  originalFileName?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(screenshots).values({
    sessionId,
    uploadedBy,
    uploadedByRole,
    storageUrl,
    storageKey,
    originalFileName,
  });
}

export async function getSessionScreenshots(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(screenshots)
    .where(eq(screenshots.sessionId, sessionId));
}

/**
 * Annotations Queries
 */
export async function addAnnotation(
  sessionId: number,
  type: "freehand" | "arrow" | "rectangle" | "circle" | "line" | "text",
  data: any,
  color?: string,
  strokeWidth?: number,
  screenshotId?: number
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(annotations).values({
    sessionId,
    type,
    data,
    color: color || "#000000",
    strokeWidth: strokeWidth || 2,
    screenshotId,
  });
}

export async function getSessionAnnotations(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(annotations)
    .where(eq(annotations.sessionId, sessionId));
}

/**
 * Session History Queries
 */
export async function createSessionHistory(
  sessionId: number,
  technicianId: number,
  clientId: number | undefined,
  clientName: string | undefined,
  clientEmail: string | undefined,
  totalDuration?: number,
  notes?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(sessionHistory).values({
    sessionId,
    technicianId,
    clientId,
    clientName,
    clientEmail,
    totalDuration,
    notes,
  });
}

export async function getSessionHistoryBySessionId(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(sessionHistory)
    .where(eq(sessionHistory.sessionId, sessionId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getTechnicianSessionHistory(technicianId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(sessionHistory)
    .where(eq(sessionHistory.technicianId, technicianId));
}


/**
 * Video Calls Queries
 */
export async function createVideoCall(
  sessionId: number,
  initiatedBy: number,
  initiatedByRole: "technician" | "client",
  jitsiRoomName: string,
  peripheralType?: string,
  description?: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(videoCalls).values({
    sessionId,
    initiatedBy,
    initiatedByRole,
    jitsiRoomName,
    peripheralType,
    description,
    status: "pending",
  });
}

export async function getVideoCallById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(videoCalls)
    .where(eq(videoCalls.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getSessionVideoCalls(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(videoCalls)
    .where(eq(videoCalls.sessionId, sessionId));
}

export async function updateVideoCallStatus(
  videoCallId: number,
  status: "pending" | "accepted" | "active" | "completed" | "rejected" | "cancelled"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: any = { status };
  if (status === "active") {
    updateData.startedAt = new Date();
  } else if (status === "completed" || status === "cancelled" || status === "rejected") {
    updateData.endedAt = new Date();
  }

  return await db
    .update(videoCalls)
    .set(updateData)
    .where(eq(videoCalls.id, videoCallId));
}

export async function completeVideoCall(videoCallId: number, duration: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(videoCalls)
    .set({
      status: "completed",
      endedAt: new Date(),
      duration,
    })
    .where(eq(videoCalls.id, videoCallId));
}

/**
 * Help Requests Queries
 */
export async function createHelpRequest(
  sessionId: number,
  clientId: number,
  peripheralType: string,
  description: string
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(helpRequests).values({
    sessionId,
    clientId,
    peripheralType,
    description,
    status: "pending",
  });
}

export async function getHelpRequestById(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db
    .select()
    .from(helpRequests)
    .where(eq(helpRequests.id, id))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getSessionHelpRequests(sessionId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(helpRequests)
    .where(eq(helpRequests.sessionId, sessionId));
}

export async function getPendingHelpRequests() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .select()
    .from(helpRequests)
    .where(eq(helpRequests.status, "pending"));
}

export async function updateHelpRequestStatus(
  helpRequestId: number,
  status: "pending" | "accepted" | "in_progress" | "completed" | "rejected"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(helpRequests)
    .set({ status, updatedAt: new Date() })
    .where(eq(helpRequests.id, helpRequestId));
}

export async function linkHelpRequestToVideoCall(helpRequestId: number, videoCallId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(helpRequests)
    .set({ videoCallId })
    .where(eq(helpRequests.id, helpRequestId));
}
