import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, protectedProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createSupportSession,
  getSupportSessionByAccessCode,
  getSupportSessionById,
  getTechnicianSessions,
  updateSessionStatus,
  joinSessionAsClient,
  addChatMessage,
  getSessionMessages,
  addScreenshot,
  getSessionScreenshots,
  addAnnotation,
  getSessionAnnotations,
  getSessionHistoryBySessionId,
  getTechnicianSessionHistory,
  createVideoCall,
  getVideoCallById,
  getSessionVideoCalls,
  updateVideoCallStatus,
  completeVideoCall,
  createHelpRequest,
  getHelpRequestById,
  getSessionHelpRequests,
  getPendingHelpRequests,
  updateHelpRequestStatus,
  linkHelpRequestToVideoCall,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  sessions: router({
    create: protectedProcedure
      .input(
        z.object({
          clientName: z.string().optional(),
          clientEmail: z.string().email().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }

        const accessCode = Math.random().toString(36).substring(2, 8).toUpperCase();
        await createSupportSession(
          ctx.user.id,
          accessCode,
          input.clientName,
          input.clientEmail
        );

        return { accessCode, success: true };
      }),

    list: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await getTechnicianSessions(ctx.user.id);
    }),

    getByAccessCode: publicProcedure
      .input(z.object({ accessCode: z.string() }))
      .query(async ({ input }) => {
        return await getSupportSessionByAccessCode(input.accessCode);
      }),

    join: publicProcedure
      .input(
        z.object({
          accessCode: z.string(),
          clientName: z.string().optional(),
          clientEmail: z.string().email().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const session = await getSupportSessionByAccessCode(input.accessCode);
        if (!session) {
          throw new TRPCError({ code: "NOT_FOUND", message: "Session not found" });
        }

        await joinSessionAsClient(
          session.id,
          undefined,
          input.clientName,
          input.clientEmail
        );

        return { sessionId: session.id, success: true };
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          status: z.enum(["pending", "active", "completed", "cancelled"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "admin") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await updateSessionStatus(input.sessionId, input.status);
        return { success: true };
      }),
  }),

  chat: router({
    send: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          content: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const sender = ctx.user;
        if (!sender) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        await addChatMessage(
          input.sessionId,
          sender.id,
          sender.role === "admin" ? "technician" : "client",
          input.content
        );

        return { success: true };
      }),

    getMessages: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionMessages(input.sessionId);
      }),
  }),

  media: router({
    uploadScreenshot: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          storageUrl: z.string(),
          storageKey: z.string(),
          originalFileName: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const uploader = ctx.user;
        if (!uploader) {
          throw new TRPCError({ code: "UNAUTHORIZED" });
        }

        await addScreenshot(
          input.sessionId,
          uploader.id,
          uploader.role === "admin" ? "technician" : "client",
          input.storageUrl,
          input.storageKey,
          input.originalFileName
        );

        return { success: true };
      }),

    getScreenshots: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionScreenshots(input.sessionId);
      }),

    addAnnotation: publicProcedure
      .input(
        z.object({
          sessionId: z.number(),
          type: z.enum(["freehand", "arrow", "rectangle", "circle", "line", "text"]),
          data: z.any(),
          color: z.string().optional(),
          strokeWidth: z.number().optional(),
          screenshotId: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        await addAnnotation(
          input.sessionId,
          input.type,
          input.data,
          input.color,
          input.strokeWidth,
          input.screenshotId
        );

        return { success: true };
      }),

    getAnnotations: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionAnnotations(input.sessionId);
      }),
  }),

  history: router({
    getSessionHistory: protectedProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionHistoryBySessionId(input.sessionId);
      }),

    getTechnicianHistory: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await getTechnicianSessionHistory(ctx.user.id);
    }),
  }),

  videoCalls: router({
    create: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          jitsiRoomName: z.string(),
          peripheralType: z.string().optional(),
          description: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await createVideoCall(
          input.sessionId,
          ctx.user.id,
          ctx.user.role === "admin" ? "technician" : "client",
          input.jitsiRoomName,
          input.peripheralType,
          input.description
        );
        return { success: true };
      }),

    getBySession: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionVideoCalls(input.sessionId);
      }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          videoCallId: z.number(),
          status: z.enum(["pending", "accepted", "active", "completed", "rejected", "cancelled"]),
        })
      )
      .mutation(async ({ input }) => {
        await updateVideoCallStatus(input.videoCallId, input.status);
        return { success: true };
      }),

    complete: protectedProcedure
      .input(
        z.object({
          videoCallId: z.number(),
          duration: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await completeVideoCall(input.videoCallId, input.duration);
        return { success: true };
      }),
  }),

  helpRequests: router({
    create: protectedProcedure
      .input(
        z.object({
          sessionId: z.number(),
          peripheralType: z.string(),
          description: z.string(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        if (ctx.user.role !== "user") {
          throw new TRPCError({ code: "FORBIDDEN" });
        }
        await createHelpRequest(
          input.sessionId,
          ctx.user.id,
          input.peripheralType,
          input.description
        );
        return { success: true };
      }),

    getBySession: publicProcedure
      .input(z.object({ sessionId: z.number() }))
      .query(async ({ input }) => {
        return await getSessionHelpRequests(input.sessionId);
      }),

    getPending: protectedProcedure.query(async ({ ctx }) => {
      if (ctx.user.role !== "admin") {
        throw new TRPCError({ code: "FORBIDDEN" });
      }
      return await getPendingHelpRequests();
    }),

    updateStatus: protectedProcedure
      .input(
        z.object({
          helpRequestId: z.number(),
          status: z.enum(["pending", "accepted", "in_progress", "completed", "rejected"]),
        })
      )
      .mutation(async ({ input }) => {
        await updateHelpRequestStatus(input.helpRequestId, input.status);
        return { success: true };
      }),

    linkToVideoCall: protectedProcedure
      .input(
        z.object({
          helpRequestId: z.number(),
          videoCallId: z.number(),
        })
      )
      .mutation(async ({ input }) => {
        await linkHelpRequestToVideoCall(input.helpRequestId, input.videoCallId);
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
