import { describe, expect, it, beforeEach } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(role: "admin" | "user" = "admin"): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: role === "admin" ? 1 : 2,
    openId: role === "admin" ? "tech-user" : "client-user",
    email: role === "admin" ? "tech@example.com" : "client@example.com",
    name: role === "admin" ? "Technician" : "Client",
    loginMethod: "manus",
    role: role,
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };

  return { ctx };
}

describe("videoCalls", () => {
  it("technician can create a video call", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.videoCalls.create({
      sessionId: 1,
      jitsiRoomName: "test-room-123",
      peripheralType: "mouse",
      description: "Mouse not working",
    });

    expect(result.success).toBe(true);
  });

  it("client cannot create a video call (should fail)", async () => {
    const { ctx } = createAuthContext("user");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.videoCalls.create({
        sessionId: 1,
        jitsiRoomName: "test-room-123",
        peripheralType: "mouse",
        description: "Mouse not working",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.message || error.toString()).toContain("FORBIDDEN");
    }
  });

  it("technician can update video call status", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.videoCalls.updateStatus({
      videoCallId: 1,
      status: "active",
    });

    expect(result.success).toBe(true);
  });

  it("technician can complete a video call", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.videoCalls.complete({
      videoCallId: 1,
      duration: 300,
    });

    expect(result.success).toBe(true);
  });
});

describe("helpRequests", () => {
  it("client can create a help request", async () => {
    const { ctx } = createAuthContext("user");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.helpRequests.create({
      sessionId: 1,
      peripheralType: "keyboard",
      description: "Keyboard keys not responding",
    });

    expect(result.success).toBe(true);
  });

  it("technician cannot create a help request (should fail)", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    try {
      await caller.helpRequests.create({
        sessionId: 1,
        peripheralType: "keyboard",
        description: "Keyboard keys not responding",
      });
      expect.fail("Should have thrown FORBIDDEN error");
    } catch (error: any) {
      expect(error.code).toBe("FORBIDDEN");
    }
  });

  it("technician can get pending help requests", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.helpRequests.getPending();

    expect(Array.isArray(result)).toBe(true);
  });

  it("technician can update help request status", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.helpRequests.updateStatus({
      helpRequestId: 1,
      status: "accepted",
    });

    expect(result.success).toBe(true);
  });

  it("technician can link help request to video call", async () => {
    const { ctx } = createAuthContext("admin");
    const caller = appRouter.createCaller(ctx);

    const result = await caller.helpRequests.linkToVideoCall({
      helpRequestId: 1,
      videoCallId: 1,
    });

    expect(result.success).toBe(true);
  });
});
