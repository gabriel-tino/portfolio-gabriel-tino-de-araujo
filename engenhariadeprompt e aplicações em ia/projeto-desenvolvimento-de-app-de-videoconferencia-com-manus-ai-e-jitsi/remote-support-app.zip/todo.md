# Remote Support App - TODO

## Backend - Banco de Dados e Autenticação
- [x] Criar tabelas: sessions, messages, annotations, screenshots, session_history
- [x] Implementar procedures tRPC para gerenciamento de sessões
- [x] Implementar procedures tRPC para chat em tempo real
- [x] Implementar procedures tRPC para upload de screenshots
- [x] Implementar procedures tRPC para histórico de sessões
- [x] Implementar notificações automáticas ao técnico

## Frontend - Layout e Autenticação
- [x] Configurar tema visual elegante e sofisticado
- [x] Implementar autenticação com dois papéis (técnico/admin e cliente/user)
- [x] Criar roteamento baseado em papéis de usuário
- [x] Implementar logout e gerenciamento de sessão

## Dashboard de Técnico
- [x] Criar dashboard principal com visão geral de sessões (ativas, pendentes, encerradas)
- [x] Implementar fila de atendimentos
- [x] Exibir status individual de cada sessão
- [x] Criar botão para iniciar nova sessão de suporte
- [x] Gerar código de acesso único para cada sessão

## Ferramenta de Anotação em Tela
- [x] Implementar captura de tela
- [x] Implementar desenho à mão livre
- [x] Implementar ferramentas de setas
- [x] Implementar formas geométricas (retângulo, círculo, linha)
- [x] Implementar inserção de texto
- [x] Implementar cores e espessura de linha customizáveis
- [x] Implementar desfazer/refazer

## Chat e Compartilhamento
- [x] Implementar chat em tempo real entre técnico e cliente
- [x] Implementar upload de screenshots anotadas
- [x] Implementar compartilhamento de screenshots dentro da sessão
- [x] Implementar histórico de mensagens

## Histórico de Sessões
- [x] Implementar visualização de histórico completo de sessões
- [x] Armazenar todas as anotações
- [x] Armazenar todas as mensagens
- [x] Armazenar todos os arquivos salvos
- [x] Implementar busca e filtros no histórico

## Página do Cliente
- [x] Criar página de acesso para cliente com código de sessão
- [x] Implementar interface de cliente durante sessão de suporte
- [x] Exibir anotações do técnico em tempo real
- [x] Implementar chat para cliente

## Refinamentos e Testes
- [x] Testes de funcionalidade (12 testes Vitest - 100% aprovação)
- [x] Otimizações de performance
- [x] Refinamentos visuais
- [x] Testes de responsividade

## Integração Jitsi Meet - Videoconferência
- [x] Configurar API do Jitsi Meet e tokens JWT
- [x] Criar tabela de video_calls para registrar videochamadas
- [x] Implementar procedures tRPC para solicitar videochamada
- [x] Implementar procedures tRPC para aceitar/rejeitar videochamada
- [x] Implementar procedures tRPC para encerrar videochamada
- [x] Criar componente JitsiMeetComponent com integração completa
- [x] Implementar interface de solicitação de ajuda com periféricos
- [x] Adicionar tipos de periféricos (Mouse, Teclado, Monitor, Webcam, etc)
- [x] Integrar notificação de solicitação de videochamada no dashboard do técnico
- [x] Adicionar histórico de videochamadas ao histórico de sessões
- [x] Implementar testes para fluxo de videochamadas (9 testes - 100% aprovação)
- [x] Validar integração com Jitsi Meet

## Melhorias Futuras (Opcional)
- [ ] Implementar geração/uso de JWT do Jitsi Meet no backend para maior segurança
- [ ] Implementar polling automático para notificações em tempo real
- [ ] Adicionar gravação de videochamadas
- [ ] Implementar suporte a múltiplos participantes na videochamada
- [ ] Adicionar compartilhamento de tela durante videochamada
- [ ] Implementar integração com CRM para histórico de clientes


## Correção Solicitada
- [x] Integrar videoconferência Jitsi Meet diretamente na tela de sessão do técnico
- [x] Adicionar botão para iniciar videochamada na página SessionDetail
- [x] Exibir janela de vídeo embutida na interface de sessão
